# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()


def tinyMazeSearch(problem):
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem):
    """
    print "Start:", problem.getStartState()
    print "Is the start a goal?", problem.isGoalState(problem.getStartState())
    print "Start's successors:", problem.getSuccessors(problem.getStartState())
    """

    stack = util.Stack()
    stack.push((problem.getStartState(), [], []))
    while not stack.isEmpty():
        p, d, v = stack.pop()
        
        if problem.isGoalState(p):
            return d
        for np, nd, x in problem.getSuccessors(p):
            if not np in v:
                stack.push((np, d + [nd], v + [p]))
                sol = d + [nd]

    print (sol)
    return sol
   
    util.raiseNotDefined()
    
def randomSearch(problem): 
    from random import random
    current = problem.getStartState() 
    solution = [] 
    while not (problem.isGoalState(current))  : 
            succ = problem.getSuccessors(current) 
            no_of_successors = len(succ) 
            random_succ_index = int(random() * no_of_successors) 
            next = succ[random_succ_index] 
            current = next[0] 
            solution.append(next[1]) 
    print ("The solution is ", solution)
    return solution

    util.raiseNotDefined()

def breadthFirstSearch(problem):
    queue = util.Queue()
    queue.push((problem.getStartState(), [], []))
    while not queue.isEmpty():
        p, d, v = queue.pop()
        if problem.isGoalState(p):
            return d
        for np, nd, x in problem.getSuccessors(p):
            if not np in v:
                queue.push((np, d + [nd], v + [p]))
                sol = d + [nd]
    print (sol)
    return sol

    util.raiseNotDefined()

def uniformCostSearch(problem):
    """Search the node of least total cost first."""
    frontier = util.PriorityQueue()
    frontier.push((problem.getStartState(), [], 0), 0)
    explored = set()

    while not frontier.isEmpty():
        (state, actions, cost) = frontier.pop()
        if state not in explored:
            explored.add(state)
            if problem.isGoalState(state):
                return actions
            for nextState, nextActions, nextCost in problem.getSuccessors(state):
                frontier.push((nextState, actions + [nextActions], cost + nextCost), cost + nextCost)
    return []

    util.raiseNotDefined()

def nullHeuristic(state, problem=None):
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0

def aStarSearch(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    prior_queue = util.PriorityQueue()
    visited = []

    # (location, path, cost)
    start_state = (problem.getStartState(), [], 0)
    prior_queue.push(start_state, 0)

    while not prior_queue.isEmpty():
        state = prior_queue.pop()
        if problem.isGoalState(state[0]):
            return state[1]

        if not state[0] in visited:
            visited.append(state[0])

            successors = problem.getSuccessors(state[0])
            for successor in successors:
                if not successor[0] in visited:
                    # total_cost = cost + heuristic
                    cost = state[2] + successor[2]
                    total_cost = cost + heuristic(successor[0], problem)
                    new_state = (successor[0], state[1] + [successor[1]], cost)
                    prior_queue.push(new_state, total_cost)

    return nullHeuristic(problem)

    util.raiseNotDefined()

# Weighted A*
def aStarSearch1(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    priority_queue = util.PriorityQueue()
    visited = []
    start_state = (problem.getStartState(), [], 0)
    priority_queue.push(start_state, 0)
    while not priority_queue.isEmpty():
        state = priority_queue.pop()
        if problem.isGoalState(state[0]):
            return state[1]
        if not state[0] in visited:
            visited.append(state[0])
            successors = problem.getSuccessors(state[0])
            for successor in successors:
                if not successor[0] in visited:
                    cost = state[2] + successor[2]
                    total_cost = cost + 5 * heuristic(successor[0], problem)
                    new_state = (successor[0], state[1] + [successor[1]], cost)
                    priority_queue.push(new_state, total_cost)
    return nullHeuristic(problem)

# Fringe search
def aStarSearch2 (problem, heuristic):
    fringe = util.PriorityQueue()
    visited = []
    temp = []
    later = []
    now = util.PriorityQueue()

    fringe.push(problem.getStartState(), 0)
    current_state = fringe.pop()
    while not problem.isGoalState(current_state):
        if current_state not in visited:
            visited.append(current_state)
            successors = problem.getSuccessors(current_state)
            for successor in successors:
                temp = later + [successor[1]]
                total_cost = problem.getCostOfActions(temp) + heuristic(successor[0], problem)
                if successor[0] not in visited:
                    fringe.push(successor[0], total_cost)
                    now.push(temp, total_cost)
        current_state = fringe.pop()
        later = now.pop()

    return later

#Variation of UCS using heuristic
def aStarSearch3(problem, heuristic=nullHeuristic):
    """Search the node that has the lowest combined cost and heuristic first."""
    frontier = util.PriorityQueue()
    frontier.push((problem.getStartState(), []), 0)
    explored = set()
  
    while not frontier.isEmpty():
        (state, actions) = frontier.pop()        
        if state not in explored:
            explored.add(state)
            if problem.isGoalState(state):
                return actions
            for nextState, nextActions, nextCost in problem.getSuccessors(state):
                frontier.push((nextState, actions + [nextActions]), nextCost + heuristic(nextState, problem))
    return []

    util.raiseNotDefined()

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar1 = aStarSearch1
astar2 = aStarSearch2
astar3 = aStarSearch3
ucs = uniformCostSearch
rs = randomSearch